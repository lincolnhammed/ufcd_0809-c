#include <stdio.h>
/*
Contagem Regressiva:
Escreva um programa que faça uma contagem regressiva de 10 até 1 e depois mostre "Fogo!".
*/
int main() {
      for(int i=10;i>0;i--) printf("%d\n",i);
    printf("FOGO!!!");
    return 0;
}